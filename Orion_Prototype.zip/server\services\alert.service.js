// FILE: services/alert.service.js

const generateAlertMessage = (data) => {
  if (!data || typeof data !== 'object') {
    throw new Error('Valid data object is required');
  }

  const { text, severity, response, location } = data;

  if (!text || !severity || !response || !response.message) {
    throw new Error('Missing required fields for alert generation');
  }

  const locationLink = location && location.mapLink ? location.mapLink : 'N/A';

  const message = `EMERGENCY ALERT:
Symptom: ${text}
Severity: ${severity}
Advice: ${response.message}
Location: ${locationLink}`;

  const encodedMessage = encodeURIComponent(message);
  const whatsappLink = `https://wa.me/?text=${encodedMessage}`;

  return {
    message,
    whatsappLink,
  };
};

module.exports = {
  generateAlertMessage,
};