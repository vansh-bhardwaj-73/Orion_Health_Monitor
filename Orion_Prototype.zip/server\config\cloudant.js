// FILE: config/cloudant.js
require('dotenv').config();
const { CloudantV1 } = require('@ibm-cloud/cloudant');
const { IamAuthenticator } = require('ibm-cloud-sdk-core');

let cloudant;
let dbName = process.env.CLOUDANT_DB;

const initCloudant = async () => {
  try {
    cloudant = CloudantV1.newInstance({
      authenticator: new IamAuthenticator({
        apikey: process.env.CLOUDANT_APIKEY,
      }),
      serviceUrl: process.env.CLOUDANT_URL,
    });

    // Check if DB exists
    try {
      await cloudant.getDatabaseInformation({ db: dbName });
      console.log(`Cloudant DB "${dbName}" already exists`);
    } catch (err) {
      if (err.status === 404) {
        await cloudant.putDatabase({ db: dbName });
        console.log(`Cloudant DB "${dbName}" created`);
      } else {
        throw err;
      }
    }
  } catch (error) {
    console.error('Cloudant initialization failed:', error.message);
    throw error;
  }
};

const getClient = () => {
  if (!cloudant) {
    throw new Error('Cloudant not initialized');
  }
  return cloudant;
};

const getDbName = () => dbName;

module.exports = {
  initCloudant,
  getClient,
  getDbName,
};