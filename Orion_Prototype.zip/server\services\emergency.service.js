// FILE: services/emergency.service.js

const generateEmergencyResponse = (severity, text) => {
  if (!severity) {
    throw new Error('Severity is required');
  }

  switch (severity) {
    case 'critical':
      // Dynamic first-aid based on keywords
      const lowerText = text.toLowerCase();
      let firstAid = [
        'Call emergency services immediately (911)',
        'Stay calm and safely position the patient',
      ];
      
      if (lowerText.includes('bleeding')) {
        firstAid.push('Apply firm, direct pressure to the wound with a clean cloth.');
        firstAid.push('Elevate the injured area above the heart if possible.');
      } else if (lowerText.includes('chest pain') || lowerText.includes('heart')) {
        firstAid.push('Have the patient sit down, rest, and loosen tight clothing.');
        firstAid.push('If they are prescribed nitroglycerin or aspirin, assist them in taking it.');
      } else if (lowerText.includes('breathe') || lowerText.includes('choking')) {
        firstAid.push('Check airway. If choking, perform abdominal thrusts (Heimlich).');
        firstAid.push('If unconscious and not breathing, begin CPR.');
      } else if (lowerText.includes('burn')) {
        firstAid.push('Cool the burn under cool running water for at least 10 minutes.');
        firstAid.push('Cover loosely with sterile, non-fluffy dressing.');
      } else {
        firstAid.push('Do not move the patient unless they are in immediate danger.');
      }

      return {
        message: 'CRITICAL EMERGENCY DETECTED. SOS Activated.',
        action: firstAid,
      };

    case 'high':
      return {
        message: 'High severity symptoms detected.',
        action: [
          'Consult a doctor or urgent care soon',
          'Monitor condition closely',
        ],
      };

    case 'medium':
      return {
        message: 'Moderate symptoms detected.',
        action: [
          'Rest and monitor',
          'Take over-the-counter medication if appropriate',
        ],
      };

    case 'low':
      return {
        message: 'Low severity symptoms.',
        action: [
          'Home care is sufficient',
          'Stay hydrated and rest',
        ],
      };

    default:
      throw new Error('Invalid severity level');
  }
};

module.exports = {
  generateEmergencyResponse,
};