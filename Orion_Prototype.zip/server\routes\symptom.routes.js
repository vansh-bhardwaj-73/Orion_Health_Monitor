// FILE: routes/symptom.routes.js (updated)
const express = require('express');
const router = express.Router();
const { logSymptom, getUserSymptoms } = require('../services/symptom.service');
const { classifySymptom } = require('../services/classifier.service');
const { generateEmergencyResponse } = require('../services/emergency.service');
const { generateLocationLink } = require('../services/location.service');
const { generateAlertMessage } = require('../services/alert.service');
const { sendEmergencySMS } = require('../services/sms.service');
const { getUserById } = require('../services/user.service');

router.post('/log', async (req, res) => {
  try {
    const { text, userId, lat, lng, isSOS, ...rest } = req.body;

    if (!text || !userId) {
      return res.status(400).json({ error: 'text and userId are required' });
    }

    // If SOS button was clicked, forcefully classify as critical
    let classification;
    if (isSOS) {
      classification = { severity: 'critical', confidence: 1.0, tags: ['SOS'] };
    } else {
      classification = classifySymptom(text);
    }

    const response = generateEmergencyResponse(classification.severity, text);

    let location;
    let alert;
    let smsSent = false;

    if (classification.severity === 'critical') {
      if (lat !== undefined && lng !== undefined) {
         location = generateLocationLink(lat, lng);
      } else {
         // Fallback if no location
         location = { mapLink: 'Location Not Provided' };
      }

      alert = generateAlertMessage({
        text,
        severity: classification.severity,
        response,
        location,
      });

      // Fetch user to get emergency contact
      try {
        const user = await getUserById(userId);
        if (user && user.emergencyContact) {
          smsSent = sendEmergencySMS(user.emergencyContact, alert.message);
        }
      } catch (err) {
        console.warn('Failed to fetch user for SMS dispatch:', err.message);
      }
    }

    const symptomData = {
      userId,
      text,
      severity: classification.severity,
      confidence: classification.confidence,
      tags: classification.tags,
      response,
      ...(location && { location }),
      ...(alert && { alert }),
      smsSent,
      ...rest,
    };

    const result = await logSymptom(symptomData);
    
    // Pass back alert URL explicitly for the frontend to open
    if (alert && alert.whatsappLink) {
       result.whatsappLink = alert.whatsappLink;
    }

    res.status(201).json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/:userId', async (req, res) => {
  try {
    const symptoms = await getUserSymptoms(req.params.userId);
    res.status(200).json(symptoms);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;