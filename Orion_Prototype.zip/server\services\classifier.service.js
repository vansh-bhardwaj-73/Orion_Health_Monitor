// FILE: services/classifier.service.js
const RULES = {
  critical: [
    'chest pain',
    "can't breathe",
    'cant breathe',
    'breathlessness',
    'heavy bleeding',
    'unconscious',
  ],
  high: [
    'high fever',
    'severe pain',
    'vomiting continuously',
  ],
  medium: [
    'moderate pain',
    'mild fever',
    'dizziness',
  ],
  low: [
    'headache',
    'cold',
    'tired',
  ],
};

const CONFIDENCE_MAP = {
  critical: 0.9,
  high: 0.75,
  medium: 0.6,
  low: 0.4,
};

const PRIORITY = ['critical', 'high', 'medium', 'low'];

const classifySymptom = (text) => {
  if (!text || typeof text !== 'string') {
    throw new Error('Valid symptom text is required');
  }

  const input = text.toLowerCase();
  const matched = {
    critical: [],
    high: [],
    medium: [],
    low: [],
  };

  // Match keywords
  for (const level of PRIORITY) {
    for (const keyword of RULES[level]) {
      if (input.includes(keyword)) {
        matched[level].push(keyword);
      }
    }
  }

  // Determine highest severity
  let severity = 'low';
  for (const level of PRIORITY) {
    if (matched[level].length > 0) {
      severity = level;
      break;
    }
  }

  // Collect tags (all matched keywords)
  const tags = [
    ...matched.critical,
    ...matched.high,
    ...matched.medium,
    ...matched.low,
  ];

  const confidence = CONFIDENCE_MAP[severity];

  return {
    severity,
    confidence,
    tags,
  };
};

module.exports = {
  classifySymptom,
};