// FILE: services/sms.service.js

const sendEmergencySMS = (contactNumber, message) => {
  if (!contactNumber) {
    console.warn('SMS Mock: No emergency contact number provided.');
    return false;
  }

  // Simulate API call to SMS Gateway (e.g. Twilio)
  console.log('\n=========================================');
  console.log('📱 MOCK SMS DISPATCHED');
  console.log('=========================================');
  console.log(`TO: ${contactNumber}`);
  console.log(`MESSAGE:\n${message}`);
  console.log('=========================================\n');

  return true;
};

module.exports = {
  sendEmergencySMS,
};
